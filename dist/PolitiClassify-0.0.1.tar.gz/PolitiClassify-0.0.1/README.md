# PolitiClassify
A python package for classifying Twitter users' political orientation with two-step deep learning models.
